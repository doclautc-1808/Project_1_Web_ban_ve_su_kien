//mapping tương ứng với response trả về từ server
export interface Category {
    id: number;
    name: string;
}