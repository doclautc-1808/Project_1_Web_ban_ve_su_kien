export interface TicketDTO {
    ticket_category_id: number;
    user_id: number;
    ticket_order_detail_id: number;
}