export interface Organization {
    id: number;
    name: string;
}