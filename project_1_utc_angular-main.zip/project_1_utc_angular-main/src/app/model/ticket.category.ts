export interface TicketCategory {
    id: number;
    category_name: string;
    price: number;
    remaining_count: number;
}