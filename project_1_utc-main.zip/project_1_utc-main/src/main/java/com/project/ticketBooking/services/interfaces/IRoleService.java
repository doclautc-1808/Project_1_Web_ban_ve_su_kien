package com.project.ticketBooking.services.interfaces;

import com.project.ticketBooking.models.Role;

import java.util.List;

public interface IRoleService {
    List<Role> getAllRoles();
}
