export interface EventImage {
    id: number;
    imageUrl: string;
    image_url: string;
}