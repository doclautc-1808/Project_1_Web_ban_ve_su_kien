My pet project about Ticket Booking system:
- Restful API ✅
- Authentication and Authorization by JWT ✅
- Redis cache applied ✅
- Java Mail Sender ✅

Demo live 🎉: https://project-1-utc-angular.onrender.com/
