export const environment = {
    production: false,
    // apiBaseUrl: 'http://localhost:8090/api/v1',
    apiBaseUrl: 'https://ticketbooking-deployment.onrender.com/api/v1',
}