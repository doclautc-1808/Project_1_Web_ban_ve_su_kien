export interface TicketOrderDetail {
    id: number;
    ticket_order_id: number;
    ticket_category_id: number;
    number_of_tickets: number;
    total_money: number;
}